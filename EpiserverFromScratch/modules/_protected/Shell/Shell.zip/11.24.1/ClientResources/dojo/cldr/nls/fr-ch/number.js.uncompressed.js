define(
"dojo/cldr/nls/fr-ch/number", //begin v1.x content
{
	"currencyFormat": "¤ #,##0.00;¤-#,##0.00",
	"group": "'",
	"decimal": "."
}
//end v1.x content
);